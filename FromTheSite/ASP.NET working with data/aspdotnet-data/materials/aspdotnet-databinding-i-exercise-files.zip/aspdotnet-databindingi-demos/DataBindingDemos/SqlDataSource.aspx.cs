﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SqlDataSource : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        // TODO - insert movie
        _moviesDataSource.InsertParameters["title"].DefaultValue = "My movie";
        _moviesDataSource.InsertParameters["release_date"].DefaultValue = "01/01/2008";
        _moviesDataSource.Insert();
    }
}
