﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class TextAndValue : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string dsn = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\MovieReviews.mdf;Integrated Security=True;User Instance=True";
        using (SqlConnection conn = new SqlConnection(dsn))
        using (SqlCommand cmd = new SqlCommand("SELECT TOP 20 movie_id, title, release_date FROM movies", conn))
        {
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            DropDownList1.DataTextField = "title";
            DropDownList1.DataValueField = "movie_id";
            DropDownList1.DataSource = reader;
            DropDownList1.DataBind();
        }
    }
}
