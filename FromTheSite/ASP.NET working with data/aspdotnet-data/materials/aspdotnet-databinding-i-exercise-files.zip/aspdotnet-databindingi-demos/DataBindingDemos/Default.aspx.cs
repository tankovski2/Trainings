﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ////string dsn = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\MovieReviews.mdf;Integrated Security=True;User Instance=True";
        string dsn = ConfigurationManager.ConnectionStrings["moviesConnectionString"].ConnectionString;
        //using (SqlConnection conn = new SqlConnection(dsn))
        //using (SqlCommand cmd = new SqlCommand("SELECT TOP 20 movie_id, title, release_date FROM movies", conn))
        //{
        //    conn.Open();
        //    SqlDataReader reader = cmd.ExecuteReader();
        //    _moviesGrid.DataSource = reader;
        //    _moviesGrid.DataBind();
        //}

        //_moviesGrid.DataSource = _moviesDataSource.Select(new DataSourceSelectArguments());
        //_moviesGrid.DataBind();

    }
}
