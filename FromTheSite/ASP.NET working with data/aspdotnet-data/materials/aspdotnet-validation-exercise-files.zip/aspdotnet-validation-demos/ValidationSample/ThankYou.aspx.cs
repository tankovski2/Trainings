﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ThankYou : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        nameLabel.Text = (string)Context.Items["name"];
        ageLabel.Text = (string)Context.Items["age"];
        emailLabel.Text = (string)Context.Items["email"];
    }
}
