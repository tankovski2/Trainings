﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ServerSideValidation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void enterButton_Click(object sender, EventArgs e)
    {
        if (nameTextBox.Text == "")
            nameErrorLabel.Text = "Please fill in the name field";
        else
            nameErrorLabel.Text = "";

        if (emailTextBox.Text == "")
            emailErrorLabel.Text = "Please fill in the email field";
        else
            emailErrorLabel.Text = "";

        if (nameTextBox.Text != "" &&
            emailTextBox.Text != "")
        {
            // Use data here
        }
    }
}
