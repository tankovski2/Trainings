﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Vote : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //int age = (int)Session["age"];
        int age = -1;
        if (Request.Cookies["age"] != null)
            age = int.Parse(Request.Cookies["age"].Value);

        if (age > 18)
            Button1.Enabled = true;
        else
            Button1.Enabled = false;
    }
}
