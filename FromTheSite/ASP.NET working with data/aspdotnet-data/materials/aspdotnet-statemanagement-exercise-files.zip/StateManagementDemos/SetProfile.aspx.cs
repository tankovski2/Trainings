﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SetProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
             TextBox1.Text=Profile.name ;
             TextBox2.Text=Profile.age.ToString()  ;
             TextBox3.Text = Profile.color;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Profile.name = TextBox1.Text;
        Profile.age = int.Parse(TextBox2.Text);
        Profile.color = TextBox3.Text;
    }
}
