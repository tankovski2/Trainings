﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

public partial class QuotePage : System.Web.UI.Page
{
    static Random _rand = new Random();

    protected void Page_Load(object sender, EventArgs e)
    {
        DataTable quotes = (DataTable)Application["quotesTable"]; //new DataTable();
        //string dsn = ConfigurationManager.ConnectionStrings["QuotesConnectionString"].ConnectionString;

        //SqlDataAdapter da = new SqlDataAdapter("SELECT Author, Quote from Quotes", dsn);
        //da.Fill(quotes);

        int idx = _rand.Next(0, quotes.Rows.Count);
        _dailyQuoteLabel.Text = string.Format("{0} -{1}",
                                              quotes.Rows[idx]["Quote"],
                                              quotes.Rows[idx]["Author"]);
    }
}
