﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Target : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //string name = (string)Request.QueryString["name"] ?? "";
        //string age = (string)Request.QueryString["age"] ?? "";
        //string name = (string)Context.Items["name"];
        //int age = (int)Context.Items["age"];

        if (PreviousPage != null && PreviousPage.IsValid)
        {
            string name = "";
            int age = -1;

            age = PreviousPage.Age;
            name = PreviousPage.Name;

            //if (Request["TextBox1"] != null)
            //    name = (string)Request["TextBox1"];
            //if (Request["TextBox2"] != null)
            //    age = int.Parse((string)Request["TextBox2"]);

            Label1.Text = "Hi there " + name + " you are " +
                age.ToString() + " years old!";
        }
        else if (!PreviousPage.IsValid)
        {
            Label1.Text = "Invalid data entry...";
        }
    }
}
