﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

public partial class Source : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsCrossPagePostBack)
            File.AppendAllText(Server.MapPath("~/log.txt"), 
                    "Page was accessed!!");

        if (!IsPostBack)
            TextBox1.Text = (string)Context.Items["userName"];
    }

    public string Name { get { return TextBox1.Text; } }
    public int Age { get { return int.Parse(TextBox2.Text); } }

    protected void Button1_Click(object sender, EventArgs e)
    {
        //string name = TextBox1.Text;
        //string age = TextBox2.Text;

        //string newUrl = string.Format("Target.aspx?name={0}&age={1}", name, age);
        //Response.Redirect(newUrl);

        //Context.Items["name"] = name;
        //Context.Items["age"] = int.Parse(age);
        //Server.Transfer("Target.aspx");


    }
}
