﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : Page 
{
    protected override void OnLoad(EventArgs e)
    {
        base.OnLoad(e);

        lblMessage.Text = "";
    }

    protected void Submit_Click(object sender, EventArgs e)
    {
        if (IsValid)
            ProcessInput();
    }

    private void ProcessInput()
    {
        int age = int.Parse(txtAge.Text);

        lblMessage.Text =
            string.Format("You are {0} years old.", age);
    }
}
