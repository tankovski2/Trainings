using System;
using System.Web;
using System.Web.UI;
using System.Configuration;
using System.Web.UI.WebControls;

//
// add a reference to the following assemblies that aren't referenced by default:
//   System.Configuration
//   System.Web
//
// must turn set  DisableClientSideCountermeasuresModule to "true"
// for this module to do anything
//
namespace Pluralsight.Web.UtilityModules
{
    public class DisableClientSideCountermeasuresModule : IHttpModule
    {
        private bool ShouldDisableClientSideCountermeasures
        {
            get
            {
                bool shouldDisableClientSideCountermeasures;
                if (!bool.TryParse(ConfigurationManager.AppSettings["DisableClientSideCountermeasures"], out shouldDisableClientSideCountermeasures))
                    return false;
                else return shouldDisableClientSideCountermeasures;
            }
        }

        public void Init(HttpApplication context)
        {
            if (ShouldDisableClientSideCountermeasures)
                context.PreRequestHandlerExecute += new EventHandler(context_PreRequestHandlerExecute);
        }
        public void Dispose() { }

        // at this point, the page has not started executing
        // and the control tree is very likely not complete
        // (e.g. data binding has not yet occurred)
        // so we need to register for a handler later in the page's lifecycle
        void context_PreRequestHandlerExecute(object sender, EventArgs e)
        {
            HttpApplication app = (HttpApplication)sender;

            Page page =
                app.Context.Handler as Page;

            if (null != page)
                page.PreRenderComplete +=
                    new EventHandler(OnPreRenderCompleteDisableClientSideValidation);

        }

        // the PreRenderComplete event fires after data binding once
        // the control tree has been built and is just about ready to render
        // our handler walks the tree looking for validation controls
        // and sets EnableClientScript = false on all of them
        void OnPreRenderCompleteDisableClientSideValidation(object sender, EventArgs e)
        {
            Control topLevelControl = (Control)sender;

            WalkControlTree(topLevelControl);
        }

        private void WalkControlTree(Control control)
        {
            DisableClientSideCountermeasures(control);

            // continue searching tree for validation controls
            foreach (Control childControl in control.Controls)
                WalkControlTree(childControl);
        }

        // we might want to do more than just mess with validation controls
        private void DisableClientSideCountermeasures(Control control)
        {
            DisableClientScriptIfThisIsAValidationControl(control);

            RemoveMaxLengthIfThisIsATextBox(control);
        }

        private void DisableClientScriptIfThisIsAValidationControl(Control control)
        {
            // NOTE: this finds all built-in ASP.NET validation controls
            // if you've built your own that don't derive from BaseValidator,
            // you should add custom logic here to find them
            // and disable any client script that they generate
            BaseValidator validator = control as BaseValidator;

            if (null != validator)
                validator.EnableClientScript = false;
        }

        private void RemoveMaxLengthIfThisIsATextBox(Control control)
        {
            TextBox textBox = control as TextBox;
            if (null != textBox)
                textBox.MaxLength = 0;
        }
    }
}
