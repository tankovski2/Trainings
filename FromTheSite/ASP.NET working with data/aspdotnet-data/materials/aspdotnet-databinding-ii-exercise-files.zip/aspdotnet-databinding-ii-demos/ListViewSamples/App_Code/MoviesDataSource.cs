﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;

namespace MsdnMagazine
{
    public static class MoviesDataSource
    {
        public static DataTable GetMovies()
        {
            DataSet ret = new DataSet();
            ret.ReadXmlSchema(HttpContext.Current.Server.MapPath("~/App_Data/movies.xsd"));
            ret.ReadXml(HttpContext.Current.Server.MapPath("~/App_Data/movies.xml"));
            return ret.Tables[0];
        }
    }
}