using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class ProgrammaticParameterPopulation : Page
{
    protected void _reviewsDataSource_Inserting(object sender, 
                           SqlDataSourceCommandEventArgs e)
    {
        e.Command.Parameters["@reviewer"].Value =
          User.Identity.IsAuthenticated ? User.Identity.Name : "Anonymous";
    }
}
