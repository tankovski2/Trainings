using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Web;

namespace PS
{
    public static class MovieReviewsData
    {
        const string _connStringName = "moviereviewsConnectionString";

        public static List<Movie> GetMovies()
        {
            string dsn = ConfigurationManager.ConnectionStrings[_connStringName].ConnectionString;
            string sql = "SELECT movie_id, title, release_date FROM movies ORDER BY title";
            
            List<Movie> ret = new List<Movie>();

            using (SqlConnection conn = new SqlConnection(dsn))
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                conn.Open();
                SqlDataReader r = cmd.ExecuteReader();
                while (r.Read())
                    ret.Add(new Movie(r.GetInt32(0), r.GetString(1), r.GetDateTime(2)));
            }
            return ret;
        }

        public static List<Movie> GetMovies(int maxRows, int startRowIndex)
        {
            List<Movie> ret = new List<Movie>();

            string dsn = ConfigurationManager.ConnectionStrings[_connStringName].ConnectionString;
            // This assumes SQL Server 2005 with its new ROW_NUMBER function 
            // to assist with pagination
            //
            string sql = "SELECT movie_id, title, release_date FROM (SELECT ROW_NUMBER() OVER " +
                         "(ORDER BY title) As Row, movie_id, title, release_date FROM movies)" +
                         " As TempRowTable";

            if (startRowIndex >= 0)
            {
              sql += " WHERE Row >= " + startRowIndex.ToString() + " AND " +
                     "Row <= " + (startRowIndex + maxRows).ToString();
            }

            using (SqlConnection conn = new SqlConnection(dsn))
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                conn.Open();
                SqlDataReader r = cmd.ExecuteReader();
                while (r.Read())
                    ret.Add(new Movie(r.GetInt32(0), r.GetString(1), r.GetDateTime(2)));
            }

            return ret;
        }



        public static void UpdateMovie(Movie m)
        {
            string dsn = ConfigurationManager.ConnectionStrings[_connStringName].ConnectionString;
            string sql = "UPDATE movies SET title=@title, release_date=@release_date WHERE movie_id=@movie_id";

            using (SqlConnection conn = new SqlConnection(dsn))
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@movie_id", m.MovieId);
                cmd.Parameters.AddWithValue("@title", m.Title);
                cmd.Parameters.AddWithValue("@release_date", m.ReleaseDate);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static void DeleteMovie(Movie m)
        {
            string dsn = ConfigurationManager.ConnectionStrings[_connStringName].ConnectionString;
            string sql = "DELETE FROM movies WHERE movie_id=@movie_id";

            using (SqlConnection conn = new SqlConnection(dsn))
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@movie_id", m.MovieId);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static void InsertMovie(Movie m)
        {
            string dsn = ConfigurationManager.ConnectionStrings[_connStringName].ConnectionString;
            string sql = "INSERT INTO movies (title, release_date) VALUES (@title, @release_date)";

            using (SqlConnection conn = new SqlConnection(dsn))
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@title", m.Title);
                cmd.Parameters.AddWithValue("@release_date", m.ReleaseDate);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static int GetMovieCount(string filterExpression)
        {
            int ret = -1;
            string dsn = ConfigurationManager.ConnectionStrings[_connStringName].ConnectionString;
            string sql = "SELECT COUNT(*) FROM movies";
            if (!string.IsNullOrEmpty(filterExpression))
                sql += " WHERE title LIKE '%" + filterExpression + "%'";

            using (SqlConnection conn = new SqlConnection(dsn))
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                conn.Open();
                ret = (int)cmd.ExecuteScalar();
            }
            return ret;
        }

        public static int GetMovieCount()
        {
            return GetMovieCount("");
        }

        public static ICollection<Movie> GetMovies(string sortExpression, int maxRows, int startRowIndex)
        {
            return GetMovies("", sortExpression, maxRows, startRowIndex);
        }

         public static ICollection<Movie> GetMovies(string sortExpression)
        {
            return GetMovies("", sortExpression, -1, -1);
        }

        public static ICollection<Movie> GetMovies(string filterExpression, string sortExpression)
        {
            return GetMovies(filterExpression, sortExpression, -1, -1);
        }

        public static ICollection<Movie> GetMovies(string filterExpression, string sortExpression, int maxRows, int startRowIndex)
        {
            List<Movie> ret = new List<Movie>();

            string dsn = ConfigurationManager.ConnectionStrings[_connStringName].ConnectionString;
            // This assumes SQL Server 2005 with its new ROW_NUMBER function 
            // to assist with pagination
            // (sql query is split up in 3 parts to enable insertions)
            //
            string sql = "SELECT movie_id, title, release_date FROM (SELECT ROW_NUMBER() OVER (ORDER BY ";
            string sql2 = ") As Row, movie_id, title, release_date FROM movies ";
            string sql3 = ") As TempRowTable ";

            if (startRowIndex >= 0)
            {
                sql3 += " WHERE Row >= " + startRowIndex.ToString() + " AND " +
                       "Row <= " + (startRowIndex + maxRows).ToString();
            }

            if (!string.IsNullOrEmpty(filterExpression))
                sql3 += (startRowIndex < 0) ? " WHERE" : " AND" +
                        " title LIKE '%" + filterExpression + "%'";

            if (!string.IsNullOrEmpty(sortExpression))
            {
                sql += MovieReviewsData.ConvertSortExpressionToColumnNames(sortExpression);
                sql3 += " ORDER BY " + MovieReviewsData.ConvertSortExpressionToColumnNames(sortExpression);
            }
            else
            {
                sql += "title";
                sql3 += "ORDER BY title";
            }

            sql = sql + sql2 + sql3;

            using (SqlConnection conn = new SqlConnection(dsn))
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                conn.Open();
                SqlDataReader r = cmd.ExecuteReader();
                while (r.Read())
                    ret.Add(new Movie(r.GetInt32(0), r.GetString(1), r.GetDateTime(2)));
            }

            return ret;
        }

        public static ICollection<ReviewWithTitle> GetReviewsWithTitles(string sortExpression, int maxRows, int startRowIndex)
        {
            List<ReviewWithTitle> ret = new List<ReviewWithTitle>();

            string dsn = ConfigurationManager.ConnectionStrings[_connStringName].ConnectionString;
            // This assumes SQL Server 2005 with its new ROW_NUMBER function
            // to assist with pagination
            //
            string sql = "SELECT review_id, movie_id, summary, rating, review, reviewer, title FROM (SELECT ROW_NUMBER() OVER (ORDER BY {0}) As Row, review_id, movies.movie_id As movie_id, summary, rating, review, reviewer, movies.title as title FROM reviews, movies WHERE reviews.movie_id = movies.movie_id) As TempRowTable";

            if (startRowIndex >= 0)
            {
                sql += " WHERE Row >= " + startRowIndex.ToString() + " AND " +
                       "Row <= " + (startRowIndex + maxRows).ToString();
            }

            if (!string.IsNullOrEmpty(sortExpression))
            {
                sql = string.Format(sql,
                    MovieReviewsData.ConvertSortExpressionToColumnNames(sortExpression));
            }
            else
            {
                sql = string.Format(sql, "movies.title");
            }

            using (SqlConnection conn = new SqlConnection(dsn))
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                conn.Open();
                SqlDataReader r = cmd.ExecuteReader();
                while (r.Read())
                    ret.Add(new ReviewWithTitle(r.GetInt32(0), r.GetInt32(1), r.GetString(2), r.GetInt32(3),
                                                  r.GetString(4), r.GetString(5), r.GetString(6)));
            }

            return ret;
        }

        public static ICollection<ReviewWithTitle> GetReviewsWithTitles()
        {
            return MovieReviewsData.GetReviewsWithTitles("", -1, -1);
        }

        public static int GetReviewCount()
        {
            int ret = -1;
            string dsn = ConfigurationManager.ConnectionStrings[_connStringName].ConnectionString;
            string sql = "SELECT COUNT(*) FROM reviews";

            using (SqlConnection conn = new SqlConnection(dsn))
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                conn.Open();
                ret = (int)cmd.ExecuteScalar();
            }
            return ret;
        }

        public static ICollection<ReviewWithTitle> GetReviewsWithTitlesForAMovie(int movieId)
        {
            List<ReviewWithTitle> ret = new List<ReviewWithTitle>();

            string dsn = ConfigurationManager.ConnectionStrings[_connStringName].ConnectionString;
            string sql = "SELECT review_id, summary, rating, reviewer, movies.title FROM reviews, movies WHERE movies.movie_id=@movie_id AND reviews.movie_id = movies.movie_id";

            using (SqlConnection conn = new SqlConnection(dsn))
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@movie_id", movieId);

                conn.Open();
                SqlDataReader r = cmd.ExecuteReader();
                while (r.Read())
                    ret.Add(new ReviewWithTitle(r.GetInt32(0), movieId, r.GetString(1), r.GetInt32(2),
                                                  "", r.GetString(3), r.GetString(4)));
            }

            return ret;
        }

        public static void InsertReview(Review r)
        {
            string dsn = ConfigurationManager.ConnectionStrings[_connStringName].ConnectionString;
            string sql = "INSERT INTO [reviews] ([movie_id], [summary], [rating], [review], [reviewer]) VALUES (@movie_id, @summary, @rating, @review, @reviewer)";

            using (SqlConnection conn = new SqlConnection(dsn))
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@movie_id", r.MovieId);
                cmd.Parameters.AddWithValue("@summary", r.Summary);
                cmd.Parameters.AddWithValue("@rating", r.Rating);
                cmd.Parameters.AddWithValue("@review", r.ReviewText);
                cmd.Parameters.AddWithValue("@reviewer", r.Reviewer);

                conn.Open();
                cmd.ExecuteNonQuery();
            }

        }

        public static void UpdateReview(Review r)
        {
            string dsn = ConfigurationManager.ConnectionStrings[_connStringName].ConnectionString;
            string sql = "UPDATE reviews SET movie_id = @movie_id, summary=@summary, rating=@rating, review=@review, reviewer=@reviewer WHERE review_id=@review_id";

            using (SqlConnection conn = new SqlConnection(dsn))
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@movie_id", r.MovieId);
                cmd.Parameters.AddWithValue("@summary", r.Summary);
                cmd.Parameters.AddWithValue("@rating", r.Rating);
                cmd.Parameters.AddWithValue("@review", r.ReviewText);
                cmd.Parameters.AddWithValue("@reviewer", r.Reviewer);
                cmd.Parameters.AddWithValue("@review_id", r.ReviewId);

                conn.Open();
                cmd.ExecuteNonQuery();
            }

        }

        // Dictionary of property names to column names, 
        // used by ConvertSortExpressionToColumnNames
        //
        private static readonly Dictionary<string, string> propToColumnMap = new Dictionary<string, string>();
        static MovieReviewsData()
        {
            propToColumnMap["ReviewId"] = "review_id";
            propToColumnMap["MovieId"] = "movie_id";
            propToColumnMap["Summary"] = "summary";
            propToColumnMap["Rating"] = "rating";
            propToColumnMap["Review"] = "review";
            propToColumnMap["Reviewer"] = "reviewer";
            propToColumnMap["Title"] = "title";
            propToColumnMap["ReleaseDate"] = "release_date";
        }


        // ConvertSortExpressionToColumnNames
        // This method takes a sort expression (like "ReviewId" or "ReleaseDate DESC" 
        // and replaces any occurrences of property names contained in the propToColumnMap
        // with the corresponding column name
        // For example:
        //  input: "ReleaseDate DESC"   output: "release_date DESC"
        //  input: "ReviewId"     output: "review_id"
        //
        // This is necessary to keep the data layer complete abstracted from the UI when
        // binding these methods to an ObjectDataSource in ASP.NET
        // since by default controls like the GridView will use the property names of the data
        // classes. The only other way to deal with this would be to explicitly assign sort expressions
        // in a control like the GridView to be column names, breaking the encapsulation of the data layer
        //    
        private static string ConvertSortExpressionToColumnNames(string expr)
        {
            string key;
            string ret = expr;
            int idx = expr.IndexOf(" ASC");
            if (idx > -1)
            {
                key = expr.Substring(0, idx);
                if (propToColumnMap.ContainsKey(key))
                {
                    ret = propToColumnMap[key] + " ASC";
                }
                return ret;
            }
            idx = expr.IndexOf(" DESC");
            if (idx > -1)
            {
                key = expr.Substring(0, idx);
                if (propToColumnMap.ContainsKey(key))
                {
                    ret = propToColumnMap[key] + " DESC";
                }
                return ret;
            }
            return propToColumnMap[expr];
        }

    }
}