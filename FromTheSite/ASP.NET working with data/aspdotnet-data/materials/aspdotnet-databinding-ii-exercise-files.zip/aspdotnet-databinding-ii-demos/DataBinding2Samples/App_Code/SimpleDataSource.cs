using System;
using System.Data;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace PS
{
    public static class SimpleDataSource
    {
        public static IEnumerable<string> GetItems()
        {
            for (int i = 0; i < 10; i++)
                yield return "Item " + i.ToString();
        }

    }

}