using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace PS
{
    public class Review
    {
        int _reviewId;
        int _movieId;
        string _summary;
        int _rating;
        string _reviewText;
        string _reviewer;

        public Review() { }
        public Review(int reviewId, int movieId, string summary, int rating, string reviewText, string reviewer)
        {
            _reviewId   = reviewId;
            _movieId    = movieId;
            _summary    = summary;
            _rating     = rating;
            _reviewText = reviewText;
            _reviewer   = reviewer;
        }

        public int ReviewId
        {
            get { return _reviewId; }
            set { _reviewId = value; }
        }

        public int MovieId
        {
            get { return _movieId; }
            set { _movieId = value; }
        }

        public string Summary
        {
            get { return _summary; }
            set { _summary = value; }
        }

        public int Rating
        {
            get { return _rating; }
            set { _rating = value; }
        }

        public string ReviewText
        {
            get { return _reviewText; }
            set { _reviewText = value; }
        }

        public string Reviewer
        {
            get { return _reviewer; }
            set { _reviewer = value; }
        }
    }

    public class ReviewWithTitle : Review
    {
        string _movieTitle;

        public ReviewWithTitle() { }
        public ReviewWithTitle(int reviewId, int movieId, string summary, int rating, 
                               string review, string reviewer, string movieTitle)
            : base(reviewId, movieId, summary, rating, review, reviewer)
        {
            _movieTitle = movieTitle;
        }

        public string MovieTitle
        {
            get { return _movieTitle; }
            set { _movieTitle = value; }
        }
    }

    public class Movie
    {
        int _movieId;
        string _title;
        DateTime _releaseDate;

        public Movie() { }
        public Movie(int movieId, string title, DateTime releaseDate)
        {
            _movieId     = movieId;
            _title       = title;
            _releaseDate = releaseDate;
        }

        public int MovieId
        {
            get { return _movieId; }
            set { _movieId = value; }
        }

        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }

        public DateTime ReleaseDate
        {
            get { return _releaseDate; }
            set { _releaseDate = value; }
        }
    }

}