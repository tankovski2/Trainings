﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mvc_infrastructure.Models
{
    public class CultureModel
    {
        public decimal Amount { get; set; }
        public string Greeting { get; set; }
    }
}
