﻿using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;

namespace SimpleChat
{
    [HubName("monitor")]
    public class MonitorHub : Hub
    {

    }
}